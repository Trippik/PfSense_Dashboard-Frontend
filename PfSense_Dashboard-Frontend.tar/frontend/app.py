from flask import Flask, render_template, session, redirect, url_for
import logging
from flask_bootstrap import Bootstrap
from waitress import serve
import os

from frontend.lib import preset_forms, password_handler, db_handler

#Establish flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = "ASDSDFDFGHFGJHJKL"
bootstrap = Bootstrap(app)

#LOGIN PAGE
@app.route('/', methods=["GET","POST"])
def login():
    form = preset_forms.LoginForm()
    if form.validate_on_submit():
        username = form.username.data
        password = form.password.data
        key = password_handler.password_hash_generate(password, os.environ["SALT"])
        query = 'SELECT COUNT(*) FROM dashboard_user WHERE user_name = "{}" AND pass = "{}"'
        query = query.format(username, key)
        results = db_handler.query_db(query)
        for row in results:
            user_success = int(row[0])
        if(user_success == 1):
            query = 'SELECT id FROM dashboard_user WHERE user_name = "{}" AND pass = "{}"'
            query = query.format(username, key)
            results = db_handler.query_db(query)
            for row in results:
                session["id"] = int(row[0])
            return redirect(url_for("home"))
        else:
            logging.warning("Failed Login")
    return render_template("login.html", heading="PfSense Dashboard", form=form)

def main():
    import sys
    logging.warning(sys.executable)
    app.debug=True
    serve(app, host="0.0.0.0", port=8080, threads=str(os.environ["THREADS"]))

if __name__ == '__main__':
    main()