from flask import Blueprint, session, render_template, redirect
import logging

from frontend.lib import db_handler, web_handler, preset_forms

ovpn_pages_blueprint = Blueprint('ovpn_pages_blueprint', __name__)

#ALL INSTANCE OPENVPN PAGE
@ovpn_pages_blueprint.route("/all_openvpn", methods=["GET", "POST"])
def all_openvpn():
    if(web_handler.basic_page_verify(session["id"]) == True):
        query = """SELECT record_time, vpn_user.user_name, vpn_user.id, pfsense_instances.pfsense_name, pfsense_instances.id FROM open_vpn_access_log
LEFT JOIN vpn_user ON open_vpn_access_log.vpn_user = vpn_user.id
LEFT JOIN pfsense_instances ON open_vpn_access_log.pfsense_instance = pfsense_instances.id
ORDER BY record_time DESC 
LIMIT 50"""
        results = db_handler.query_db(query)
        filtered_results = []
        for row in results:
            new_row = []
            for item in row:
                item = str(item)
                new_row = new_row + [item]
            filtered_results = filtered_results + [new_row]
        final_results = []
        for row in filtered_results:
            final_results = final_results + [[row[0], row[1], row[3], "/vpn_user/" + row[2] + ";User Details", "/instance_details/" + row[4] + ";Instance Details"]]
        headings = ["Login Time", "User", "PfSense Instance"]
        return render_template("vertical_table.html", heading="OpenVPN Logins", headings=headings, collection=final_results)
    else:
        web_handler.user_auth_error_page()

#PER INSTANCE OPENVPN PAGE
@ovpn_pages_blueprint.route("/instance_openvpn/<id>-<offset>", methods=["GET", "POST"])
def instance_openvpn(id, offset):
    if(web_handler.basic_page_verify(session["id"]) == True):
        form = preset_forms.PreviousNext()
        if form.validate_on_submit():
            if form.previous_page.data:
                new_offset = int(offset) - 50
                if(new_offset > -1):
                    new_offset = str(new_offset)
                    return redirect("/instance_openvpn/" + str(id) + "-" + str(new_offset))
                else:
                    pass
            elif form.next_page.data:
                new_offset = int(offset) + 50
                if(new_offset > 0):
                    new_offset = str(new_offset)
                    return redirect("/instance_openvpn/" + str(id) + "-" + str(new_offset))
                else:
                    pass
        query = """SELECT record_time, vpn_user.user_name, vpn_user.id FROM open_vpn_access_log LEFT JOIN vpn_user ON open_vpn_access_log.vpn_user = vpn_user.id WHERE open_vpn_access_log.pfsense_instance = {} ORDER BY record_time DESC LIMIT {}, {}"""
        logging.warning(query.format(id, offset, "50"))
        results = db_handler.query_db(query.format(id, offset, "50"))
        filtered_results = []
        for row in results:
            new_row = []
            for item in row:
                item = str(item)
                new_row = new_row + [item]
            filtered_results = filtered_results + [new_row]
        logging.warning(filtered_results)
        final_results = []
        for row in filtered_results:
            final_results = final_results + [[row[0], row[1], "/vpn_user/" + row[2] + ";User Details"]]
        logging.warning(final_results)
        headings = ["Login Time", "User", "PfSense Instance"]
        return render_template("table_button-next_back.html", heading="OpenVPN Logins", table_headings=headings, data_collection=final_results, form=form)
    else:
        web_handler.user_auth_error_page()